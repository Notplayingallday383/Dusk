# @nightnetwork/dpm-unzip

`unzip` is a POSIX-like command for Dusk's Node-compatible JavaScript runtime.

```sh
unzip -l archive.zip
unzip archive.zip -d output
```

v1 extracts regular files and directories only. It rejects absolute and traversal paths before writing any entry, and rejects encrypted ZIP files, symbolic links, and ZIP compression methods other than stored and DEFLATE. ZIP archives using bzip2, LZMA, PPMd, Zstandard, or other unsupported methods are not supported.
