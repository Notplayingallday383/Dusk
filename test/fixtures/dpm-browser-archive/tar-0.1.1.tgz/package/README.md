# @nightnetwork/dpm-tar

`tar` is a POSIX-like command for Dusk's Node-compatible JavaScript runtime.

```sh
tar -cf archive.tar directory file
tar -tf archive.tar
tar -xf archive.tar -C output
```

v1 supports only regular files and directories. It rejects symbolic links, devices, FIFOs, traversal paths, and absolute archive paths. It reads and writes uncompressed TAR only; gzip, bzip2, xz, and zstd TAR streams are unsupported.

This package uses `nanotar` and requires a Node-compatible `node:fs/promises` implementation, as provided by Dusk.
