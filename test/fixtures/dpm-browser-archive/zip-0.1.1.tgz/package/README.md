# @nightnetwork/dpm-zip

`zip` is a POSIX-like command for Dusk's Node-compatible JavaScript runtime.

```sh
zip -r archive.zip directory
zip archive.zip file.txt
```

v1 supports only regular files and directories. `-r` is required for directory input. Symbolic links, devices, and FIFOs are rejected. This package uses `fflate` and creates ZIP archives with stored or DEFLATE data only.
